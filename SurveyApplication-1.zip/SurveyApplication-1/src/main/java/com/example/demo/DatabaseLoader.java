package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.demo.admin.*;
import com.example.demo.user.User;
import com.example.demo.user.UserRepository;

@Configuration
public class DatabaseLoader {
	
	@Autowired
	private AdminRepository repo;
	
	@Autowired
	private UserRepository userRepo;
	
	

	public DatabaseLoader(AdminRepository repo,UserRepository userRepo) {
		this.repo = repo;
		this.userRepo = userRepo;
	}
	@Bean
    public CommandLineRunner initializeDatabase() {
        return args -> {
            Admin admin1 = new Admin("laxmi@gmail.com","laxmi123");
            Admin admin2 = new Admin("venu@gmail.com","venu123");
            Admin admin3 = new Admin("prudhvi@gmail.com","pridhvi123");
            
            repo.saveAll(List.of(admin1,admin2,admin3));
            
            User user1 = new User("david@gmail.com", "david123", "david","asdkfd");
            User user2 = new User("john@yahoo.com", "john2020", "jhon","fjadfj");
 
            userRepo.saveAll(List.of(user1, user2));
             
            
        };
	}
	

}
