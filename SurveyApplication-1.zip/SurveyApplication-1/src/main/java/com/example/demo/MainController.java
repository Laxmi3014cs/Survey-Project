package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.user.User;
import com.example.demo.user.UserRepository;

@Controller
public class MainController {
	
	@Autowired
	private UserRepository repo;
	
	@GetMapping("")
	public String ViewHomePage() {
		return "index";
	}
	
	@GetMapping("/admin/login")
	public String viewAdminLoginpage() {
		return "admin/admin_login";
	}
	  
    @GetMapping("/admin/home")
    public String viewAdminHomePage() {
        return "admin/admin_home";
    }
    
    @GetMapping("/user/process")
    public String viewUserLoginAndRegistePage() {
    	return "user/index_page";
    }
    
    @GetMapping("/user/register")
    public String viewUserRegistration(Model model) {
    	 model.addAttribute("user", new User());
    	return "user/register";
    }
    
   // @RequestMapping(value = "/user/login", method = { RequestMethod.GET, RequestMethod.POST })

    @GetMapping("/user/login")
    public String viewUserLoginPage() {
    	return "user/user_login";
    }
    
    @PostMapping("/user/process_register")
	public String processRegister(User user) {

	   repo.save(user);
	     
	    return "user/register_success";
	}
    
   
   // @RequestMapping( value = "/user/home",method = RequestMethod.PUT)
    @GetMapping("/user/home")
    public String viewUserHomePage() {
        return "user/user_home";
    }
}
