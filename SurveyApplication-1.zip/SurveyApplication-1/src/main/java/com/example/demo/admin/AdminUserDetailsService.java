package com.example.demo.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class AdminUserDetailsService implements UserDetailsService {
	
	@Autowired
	private AdminRepository adminRepo;
	
	
	@Override
	public UserDetails loadUserByUsername(String emailId) throws UsernameNotFoundException {
		
		Admin admin = adminRepo.findByEmailId(emailId);
		if (admin == null) {
            throw new UsernameNotFoundException("No Admin found with the given email");
        }
         
        return new AdminUserDetails(admin);
		
		
	}

}
