package com.example.demo.user;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.SecurityFilterChain;



@Configuration
@Order(2)
public class UserSecurityConfig {
	
	@Bean
    public UserDetailsService userDetailsService1()  {
        return new CustomUserDetailsService();
    }
 
    @Bean
    public PasswordEncoder passwordEncoder1() {
        return NoOpPasswordEncoder.getInstance();
    }
 
    @Bean
    public DaoAuthenticationProvider authenticationProvider2() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService1());
        authProvider.setPasswordEncoder(passwordEncoder1());
 
        return authProvider;
    }
    
    
   
    protected SecurityFilterChain filterchani2(HttpSecurity http) throws Exception {
    	 http.authenticationProvider(authenticationProvider2());
    	 
        http.antMatcher("/user/**")
        	.authorizeRequests().anyRequest().authenticated()
            .and()
            .formLogin()
            	.loginPage("/user/process")
            	.usernameParameter("emailId")
                .loginProcessingUrl("/user/home")
                .defaultSuccessUrl("/user/login")
                .permitAll()
            .and()
            .logout().logoutUrl("/user/logout").logoutSuccessUrl("/");;
        
        return http.build();
    }
    
 

}
